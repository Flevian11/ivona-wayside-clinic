import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
export const visits = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visits.url(options),
    method: 'get',
})

visits.definition = {
    methods: ["get","head"],
    url: '/visits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
visits.url = (options?: RouteQueryOptions) => {
    return visits.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
visits.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visits.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
visits.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: visits.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
    const visitsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: visits.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
        visitsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visits.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PatientOperationsController::visits
 * @see app/Http/Controllers/PatientOperationsController.php:13
 * @route '/visits'
 */
        visitsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visits.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    visits.form = visitsForm
/**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
export const preauthorizations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preauthorizations.url(options),
    method: 'get',
})

preauthorizations.definition = {
    methods: ["get","head"],
    url: '/preauthorizations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
preauthorizations.url = (options?: RouteQueryOptions) => {
    return preauthorizations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
preauthorizations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preauthorizations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
preauthorizations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preauthorizations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
    const preauthorizationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preauthorizations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
        preauthorizationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preauthorizations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PatientOperationsController::preauthorizations
 * @see app/Http/Controllers/PatientOperationsController.php:54
 * @route '/preauthorizations'
 */
        preauthorizationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preauthorizations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preauthorizations.form = preauthorizationsForm
const PatientOperationsController = { visits, preauthorizations }

export default PatientOperationsController