import { Head, Link, router } from '@inertiajs/react';
import { CalendarClock, Search, UserRound, ArrowUpRight, ClipboardList } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

type Visit = { id:number; encounter_number:string; patient_id:number; patient_name:string|null; medical_record_number:string|null; visit_type:string; status:string; priority:string; arrived_at:string|null; department:string|null; coverage_type:string|null; sha_eligibility_status:string|null };
type Props = { visits:{data:Visit[]; current_page:number; last_page:number; total:number; links:{url:string|null; label:string; active:boolean}[]}; filters:{q:string;status:string} };
const label=(value:string|null|undefined)=>value ? value.replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase()) : '—';
const date=(value:string|null)=>value ? new Date(value).toLocaleString() : '—';
export default function VisitsIndex({visits,filters}:Props) {
 const [q,setQ]=useState(filters.q||'');
 const [status,setStatus]=useState(filters.status||'');
 const submit=(e:FormEvent)=>{e.preventDefault();router.get('/visits',{q,status},{preserveState:true,preserveScroll:true});};
 return <>
  <Head title="Visits" />
  <div className="mx-auto w-full max-w-7xl space-y-6 p-4 md:p-8">
   <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
    <div className="flex items-start gap-3"><div className="rounded-2xl bg-emerald-100 p-3 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"><CalendarClock className="h-6 w-6" /></div><div><h1 className="text-2xl font-semibold tracking-tight">Visits</h1><p className="mt-1 text-sm text-muted-foreground">Track registered outpatient, inpatient and other patient encounters.</p></div></div>
    <Button asChild><Link href="/patients/create">Register patient</Link></Button>
   </div>
   <div className="grid gap-3 sm:grid-cols-3"><div className="rounded-2xl border bg-card p-4"><p className="text-sm text-muted-foreground">Matching visits</p><p className="mt-2 text-2xl font-semibold">{visits.total}</p></div><div className="rounded-2xl border bg-card p-4"><p className="text-sm text-muted-foreground">Current page</p><p className="mt-2 text-2xl font-semibold">{visits.current_page} <span className="text-base font-normal text-muted-foreground">of {visits.last_page}</span></p></div><div className="rounded-2xl border bg-card p-4"><p className="text-sm text-muted-foreground">Workflow</p><p className="mt-2 flex items-center gap-2 text-sm font-medium"><ClipboardList className="h-4 w-4 text-emerald-700"/> Encounter records</p></div></div>
   <form onSubmit={submit} className="flex flex-col gap-3 rounded-2xl border bg-card p-4 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/><Input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search patient name, MRN or visit number" className="pl-9"/></div><select value={status} onChange={e=>setStatus(e.target.value)} className="h-10 rounded-md border bg-background px-3 text-sm"><option value="">All statuses</option>{['registered','arrived','triaged','in_progress','completed','cancelled'].map(x=><option key={x} value={x}>{label(x)}</option>)}</select><Button type="submit" variant="secondary">Apply filters</Button></form>
   <div className="overflow-hidden rounded-2xl border bg-card"><div className="border-b px-5 py-4"><h2 className="font-semibold">Visit register</h2><p className="text-sm text-muted-foreground">Latest encounters first. Open a patient record for available encounter actions.</p></div>
    {visits.data.length ? <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-muted/40 text-xs uppercase tracking-wide text-muted-foreground"><tr>{['Visit / patient','Type & coverage','Department','Arrival','Status',''].map(x=><th key={x} className="px-4 py-3 font-medium">{x}</th>)}</tr></thead><tbody className="divide-y">{visits.data.map(v=><tr key={v.id} className="hover:bg-muted/20"><td className="px-4 py-4"><p className="font-semibold">{v.encounter_number}</p><p className="mt-1 flex items-center gap-1 text-muted-foreground"><UserRound className="h-3.5 w-3.5"/>{v.patient_name||'Patient name unavailable'}</p><p className="text-xs text-muted-foreground">{v.medical_record_number||'No MRN'}</p></td><td className="px-4 py-4"><p>{label(v.visit_type)}</p><p className="text-xs text-muted-foreground">{label(v.coverage_type)}</p>{v.sha_eligibility_status&&<p className="mt-1 text-xs">SHA: {label(v.sha_eligibility_status)}</p>}</td><td className="px-4 py-4">{v.department||'—'}</td><td className="whitespace-nowrap px-4 py-4">{date(v.arrived_at)}</td><td className="px-4 py-4"><Badge variant={v.status==='completed'?'secondary':'outline'}>{label(v.status)}</Badge></td><td className="px-4 py-4"><Button variant="ghost" size="icon" asChild><Link href={`/patients/${v.patient_id}`} aria-label="Open patient record"><ArrowUpRight className="h-4 w-4"/></Link></Button></td></tr>)}</tbody></table></div>:<div className="flex flex-col items-center px-6 py-16 text-center"><div className="rounded-2xl bg-muted p-4"><CalendarClock className="h-7 w-7 text-muted-foreground"/></div><h3 className="mt-4 font-semibold">No visits found</h3><p className="mt-1 max-w-md text-sm text-muted-foreground">No encounters match these filters. Register or open a patient to start a visit, then return here to track it.</p><Button className="mt-4" asChild><Link href="/patients/create">Start patient registration</Link></Button></div>}
    {visits.last_page>1&&<div className="flex flex-wrap gap-2 border-t p-4">{visits.links.map((link,i)=><Button key={i} size="sm" variant={link.active?'default':'outline'} disabled={!link.url} onClick={()=>link.url&&router.visit(link.url,{preserveScroll:true})}>{link.label.replace('&laquo;','«').replace('&raquo;','»')}</Button>)}</div>}
   </div>
  </div>
 </>;
}
