import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ClinicSettingsController::update
 * @see app/Http/Controllers/Admin/ClinicSettingsController.php:178
 * @route '/admin/administration/system-configuration'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/administration/system-configuration',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ClinicSettingsController::update
 * @see app/Http/Controllers/Admin/ClinicSettingsController.php:178
 * @route '/admin/administration/system-configuration'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ClinicSettingsController::update
 * @see app/Http/Controllers/Admin/ClinicSettingsController.php:178
 * @route '/admin/administration/system-configuration'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ClinicSettingsController::update
 * @see app/Http/Controllers/Admin/ClinicSettingsController.php:178
 * @route '/admin/administration/system-configuration'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ClinicSettingsController::update
 * @see app/Http/Controllers/Admin/ClinicSettingsController.php:178
 * @route '/admin/administration/system-configuration'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const systemConfiguration = {
    update: Object.assign(update, update),
}

export default systemConfiguration