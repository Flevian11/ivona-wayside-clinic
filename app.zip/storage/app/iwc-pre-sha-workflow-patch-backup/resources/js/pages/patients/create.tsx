import { Head, Link, router, useForm } from '@inertiajs/react';
import { ArrowLeft, CheckCircle2, Fingerprint, HeartPulse, Search, UserRoundPlus, AlertCircle, ShieldCheck, MessageSquare, LoaderCircle, ChevronRight, ChevronLeft } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

type Props = { can: { register: boolean; shaLookup: boolean }; integrationMode: string };
type FormData = {
  registration_source: 'local'|'sha'; identifier_type: string; identifier_number: string; client_registry_id: string;
  first_name: string; middle_name: string; last_name: string; full_name: string; date_of_birth: string; sex: string; gender: string;
  phone: string; email: string; preferred_language: string; nationality: string; county: string; sub_county: string; ward: string; address: string;
  emergency_contact_name: string; emergency_contact_relationship: string; emergency_contact_phone: string;
  principal_member_patient_id: string; principal_member_client_registry_id: string; relationship_type: string; authorization_challenge_id: string; create_visit: boolean; visit_type: string; department: string; chief_complaint: string; payment_type: string; coverage_type: string; consent_type: string; consent_status: string; consent_method: string;
};
const initial: FormData = {
  registration_source:'local', identifier_type:'National ID', identifier_number:'', client_registry_id:'', first_name:'', middle_name:'', last_name:'', full_name:'', date_of_birth:'', sex:'', gender:'', phone:'', email:'', preferred_language:'', nationality:'Kenyan', county:'', sub_county:'', ward:'', address:'', emergency_contact_name:'', emergency_contact_relationship:'', emergency_contact_phone:'', principal_member_patient_id:'', principal_member_client_registry_id:'', relationship_type:'child', authorization_challenge_id:'', create_visit:true, visit_type:'outpatient', department:'', chief_complaint:'', payment_type:'', coverage_type:'', consent_type:'care_and_treatment', consent_status:'pending', consent_method:'written'
};

function Field({label,name,form,type='text',required=false,placeholder}:{label:string;name:keyof FormData;form:any;type?:string;required?:boolean;placeholder?:string}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={name} className="text-xs font-semibold text-slate-700 dark:text-slate-300">
        {label}{required && <span className="ml-1 text-rose-500">*</span>}
      </Label>
      <Input 
        id={name} 
        type={type} 
        value={String(form.data[name] ?? '')} 
        placeholder={placeholder} 
        onChange={e=>form.setData(name,e.target.value)} 
        className="h-10 rounded-xl bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 focus-visible:ring-emerald-500" 
      />
      {form.errors[name] && <p className="text-[11px] font-medium text-rose-600">{form.errors[name]}</p>}
    </div>
  );
}

export default function CreatePatient({can,integrationMode}:Props) {
 const form=useForm<FormData>(initial); 
 const [lookupStatus,setLookupStatus]=useState(''); 
 const [lookupBusy,setLookupBusy]=useState(false); 
 const [registryPatient,setRegistryPatient]=useState<any|null>(null); 
 const [registryDependants,setRegistryDependants]=useState<any[]>([]); 
 const [duplicateMatches,setDuplicateMatches]=useState<any[]>([]); 
 const [duplicateStatus,setDuplicateStatus]=useState(''); 
 const [duplicateBusy,setDuplicateBusy]=useState(false);
 const [step,setStep]=useState(1);
 const [authorizationMethod,setAuthorizationMethod]=useState<'otp'|'biometric'>('otp');
 const [authorizationBusy,setAuthorizationBusy]=useState(false);
 const [authorizationChallenge,setAuthorizationChallenge]=useState<string|null>(null);
 const [authorizationCode,setAuthorizationCode]=useState<string|null>(null);
 const [authorizationOtp,setAuthorizationOtp]=useState('');
 const [authorizationStatus,setAuthorizationStatus]=useState('');
 const [authorizationVerified,setAuthorizationVerified]=useState(false);
 
 const setSource=(value:'local'|'sha')=>form.setData(data=>({
   ...data,
   registration_source:value,
   ...(value==='sha'
     ? {consent_type:'',consent_status:'',consent_method:''}
     : {consent_type:data.consent_type||'care_and_treatment',consent_status:data.consent_status||'pending',consent_method:data.consent_method||'written'})
 }));
 
 const csrfHeaders=()=>{const token=document.cookie.split('; ').find(row=>row.startsWith('XSRF-TOKEN='))?.split('=').slice(1).join('=');return {'Content-Type':'application/json','Accept':'application/json','X-Requested-With':'XMLHttpRequest',...(token?{'X-XSRF-TOKEN':decodeURIComponent(token)}:{})};};
 const readJson=async(response:Response)=>{const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.message||data.errors?.identification_number||data.errors?.q||`Request failed (${response.status}).`);return data;};
 const setFormFromRegistry=(person:any)=>{const nameParts=String(person.full_name||person.name||[person.first_name||person.given_name,person.middle_name,person.last_name||person.family_name].filter(Boolean).join(' ')).trim().split(/\s+/);const first=person.first_name||person.given_name||nameParts[0]||'';const last=person.last_name||person.family_name||(nameParts.length>1?nameParts[nameParts.length-1]:'');const middle=person.middle_name||(nameParts.length>2?nameParts.slice(1,-1).join(' '):'');form.setData(data=>({...data,client_registry_id:String(person.id||person.client_registry_id||data.client_registry_id||''),first_name:first,middle_name:middle,last_name:last,full_name:person.full_name||person.name||[first,middle,last].filter(Boolean).join(' '),date_of_birth:String(person.date_of_birth||person.birthDate||data.date_of_birth||'').slice(0,10),sex:String(person.sex||person.gender||data.sex||'').toLowerCase(),gender:person.gender||data.gender,phone:person.phone||person.telecom?.find?.((x:any)=>x.system==='phone')?.value||data.phone,email:person.email||data.email,county:person.county||data.county,sub_county:person.sub_county||data.sub_county,ward:person.ward||data.ward,registration_source:'sha',consent_type:'',consent_status:'',consent_method:''}));setLookupStatus('');};
 const lookupSha=async()=>{if(!form.data.identifier_number.trim()){setLookupStatus('Enter an identifier number first.');return;}setLookupBusy(true);setLookupStatus('');setRegistryPatient(null);setRegistryDependants([]);try{const response=await fetch('/patients/sha-lookup',{method:'POST',headers:csrfHeaders(),credentials:'same-origin',body:JSON.stringify({identification_type:form.data.identifier_type,identification_number:form.data.identifier_number.trim()})});const result=await readJson(response);if(!result.found||!result.patient){setLookupStatus(result.mock?'No matching development fixture was returned. No live SHA/HIE request was made.':'No matching Client Registry record was returned. Check the identifier and try again.');return;}const person=result.patient;setRegistryPatient(person);const confirmed=(result.dependants||[]).map((d:any)=>({...d,relationship_verified:true}));const unconfirmed=(result.unconfirmed_dependants||[]).map((d:any)=>({...d,relationship_verified:false}));setRegistryDependants([...confirmed,...unconfirmed]);setFormFromRegistry(person);setLookupStatus(result.mock?'Development fixture loaded — synthetic data only; no live SHA/HIE request was made.':'Client Registry result received. Review the returned details before saving.');}catch(error){setLookupStatus(error instanceof Error?error.message:'Client Registry lookup failed.');}finally{setLookupBusy(false);}};
 const chooseDependant=(person:any)=>{setFormFromRegistry(person);form.setData(data=>({...data,identifier_type:'ClientRegistry ID',identifier_number:String(person.identification_number||person.id||''),client_registry_id:String(person.id||''),principal_member_client_registry_id:String(registryPatient?.id||registryPatient?.client_registry_id||''),principal_member_patient_id:'',relationship_type:String(person.relationship||person.relationship_type||'child').toLowerCase().replace(/\\s+/g,'_'),authorization_challenge_id:'',registration_source:'sha',consent_type:'',consent_status:'',consent_method:'',create_visit:true}));setAuthorizationVerified(false);setAuthorizationChallenge(null);setAuthorizationCode(null);setAuthorizationOtp('');setAuthorizationStatus('Dependant selected. The principal member must authorize this dependant before the visit can be started.');setStep(2);};
 const startAuthorization=async(method:'otp'|'biometric')=>{if(!registryPatient?.id||!form.data.client_registry_id||!form.data.principal_member_client_registry_id){setAuthorizationStatus('Select a dependant from the principal member registry result first.');return;}setAuthorizationBusy(true);setAuthorizationStatus('Starting principal-member authorization…');setAuthorizationMethod(method);setAuthorizationVerified(false);try{const response=await fetch('/patients/principal-authorization/start',{method:'POST',headers:csrfHeaders(),credentials:'same-origin',body:JSON.stringify({method,principal_registry_id:form.data.principal_member_client_registry_id,dependent_registry_id:form.data.client_registry_id})});const result=await readJson(response);setAuthorizationChallenge(result.challenge_id);setAuthorizationCode(result.test_code||null);setAuthorizationStatus(result.message||'Authorization challenge started.');}catch(error){setAuthorizationStatus(error instanceof Error?error.message:'Could not start authorization.');}finally{setAuthorizationBusy(false);}};
 const verifyAuthorization=async(method:'otp'|'biometric',otp?:string)=>{if(!authorizationChallenge){setAuthorizationStatus('Start a new authorization challenge first.');return;}setAuthorizationBusy(true);setAuthorizationStatus(method==='otp'?'Verifying the principal OTP…':'Requesting simulated biometric confirmation…');try{const response=await fetch('/patients/principal-authorization/verify',{method:'POST',headers:csrfHeaders(),credentials:'same-origin',body:JSON.stringify({challenge_id:authorizationChallenge,method,otp,biometric_scenario:'match'})});const result=await readJson(response);if(!result.verified){setAuthorizationStatus(result.message||'Authorization was not confirmed.');return;}setAuthorizationVerified(true);form.setData(data=>({...data,authorization_challenge_id:authorizationChallenge}));setAuthorizationStatus(result.message||'Principal authorization confirmed.');setStep(3);}catch(error){setAuthorizationStatus(error instanceof Error?error.message:'Authorization failed.');}finally{setAuthorizationBusy(false);}};
 const checkDuplicates=async()=>{const name=form.data.full_name||[form.data.first_name,form.data.middle_name,form.data.last_name].filter(Boolean).join(' ');const query=name||form.data.client_registry_id||'';const params={query,date_of_birth:form.data.date_of_birth,phone:form.data.phone,identifier_type:form.data.identifier_type,identifier_number:form.data.identifier_number};if(!Object.values(params).some(v=>String(v||'').trim())){setDuplicateStatus('Enter an identifier, name, date of birth or phone number before checking.');setDuplicateMatches([]);return [];}setDuplicateBusy(true);setDuplicateStatus('');try{const response=await fetch('/patients/duplicate-check',{method:'POST',headers:csrfHeaders(),credentials:'same-origin',body:JSON.stringify(params)});const result=await readJson(response);setDuplicateMatches(Array.isArray(result.matches)?result.matches:[]);setDuplicateStatus(result.matches?.length?`Found ${result.matches.length} possible existing record(s). Open an existing record and start a visit there if this is the same patient.`:'Automatic duplicate check passed: no likely local matches were found.');return Array.isArray(result.matches)?result.matches:[];}catch(error){setDuplicateStatus(error instanceof Error?error.message:'Local duplicate check failed.');throw error;}finally{setDuplicateBusy(false);}};
 const advanceToVisit=async()=>{try{const matches=await checkDuplicates();if(matches.length){setDuplicateStatus(`Possible existing record${matches.length===1?'':'s'} found. Open the correct record to start a visit, or review the details before continuing.`);return;}setStep(4);}catch{setDuplicateStatus('The automatic duplicate check failed. Fix the connection before continuing; nothing has been saved.');}};
 const submit=async(e:FormEvent)=>{e.preventDefault();if(form.processing||duplicateBusy)return;setDuplicateMatches([]);try{const matches=await checkDuplicates();if(matches.length>0){setDuplicateStatus(`Registration paused: ${matches.length} possible existing patient record(s) found. Open and review a match before proceeding.`);setStep(3);return;}form.post('/patients',{preserveScroll:true});}catch{setDuplicateStatus('Registration paused because the automatic duplicate check failed. Check the connection and retry; no patient was saved.');}};

 return (
  <>
   <Head title="Register patient | Ivona Wayside Clinic" />
   <main className="min-h-screen w-full bg-[#f4f8f6] dark:bg-[#08131a] px-4 py-5 md:px-6 md:py-6 transition-colors duration-300">
    <div className="mx-auto w-full max-w-none space-y-5">
     
     {/* HEADER */}
     <div className="flex items-start gap-4">
       <Link href="/dashboard" className="mt-0.5 rounded-xl border border-slate-200 bg-white p-2.5 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors">
         <ArrowLeft className="h-4 w-4" />
       </Link>
       <div>
         <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-900/10 bg-emerald-50 dark:border-emerald-400/20 dark:bg-emerald-950/40 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.17em] text-emerald-900 dark:text-emerald-300">
            Patient care · Front desk
         </span>
         <h1 className="mt-2 text-2xl md:text-3xl font-bold tracking-tight text-slate-950 dark:text-slate-50">New patient / visit</h1>
         <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Find an existing patient first. Reuse their record for every return visit.</p>
       </div>
     </div>

     <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
      
      {/* MAIN FORM */}
      <form onSubmit={submit} className="space-y-5">
       <div className="grid grid-cols-4 gap-2 rounded-2xl border border-slate-100 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-[#111c2d]">
         {[{n:1,label:'Find patient'},{n:2,label:'Authorize'},{n:3,label:'Patient details'},{n:4,label:'Start visit'}].map(item=><div key={item.n} className={`rounded-xl px-2 py-2 text-center ${step===item.n?'bg-emerald-700 text-white':step>item.n?'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300':'bg-slate-50 text-slate-500 dark:bg-slate-900'}`}><span className="mx-auto flex h-6 w-6 items-center justify-center rounded-full border border-current text-xs font-bold">{step>item.n?<CheckCircle2 className="h-4 w-4"/>:item.n}</span><span className="mt-1 block text-[10px] font-semibold sm:text-xs">{item.label}</span></div>)}
       </div>
       
       {step === 1 && (<>
       {/* PATHWAY */}
       <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm">
         <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
           <div>
             <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Registration pathway</h2>
             <p className="text-xs text-slate-500 dark:text-slate-400">Choose how this patient will be identified.</p>
           </div>
           <Badge variant="outline" className="text-[10px] border-slate-200 dark:border-slate-700">
             {integrationMode==='development'?'Development · mock integrations':integrationMode.toUpperCase()}
           </Badge>
         </div>
         <div className="grid gap-3 sm:grid-cols-2">
           <button type="button" onClick={()=>setSource('local')} className={`rounded-xl border p-4 text-left transition-all ${form.data.registration_source==='local'?'border-emerald-500 bg-emerald-50/50 dark:border-emerald-500/50 dark:bg-emerald-950/20 ring-1 ring-emerald-500':'border-slate-200 hover:border-emerald-200 dark:border-slate-700 dark:hover:border-slate-600'}`}>
             <div className="flex items-center justify-between">
               <UserRoundPlus className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
               {form.data.registration_source==='local'&&<CheckCircle2 className="h-4 w-4 text-emerald-600" />}
             </div>
             <h3 className="mt-3 text-sm font-bold text-slate-900 dark:text-slate-100">Local / non-SHA patient</h3>
             <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">No external lookup required. Capture the details currently available.</p>
           </button>
           <button type="button" onClick={()=>setSource('sha')} className={`rounded-xl border p-4 text-left transition-all ${form.data.registration_source==='sha'?'border-emerald-500 bg-emerald-50/50 dark:border-emerald-500/50 dark:bg-emerald-950/20 ring-1 ring-emerald-500':'border-slate-200 hover:border-emerald-200 dark:border-slate-700 dark:hover:border-slate-600'}`}>
             <div className="flex items-center justify-between">
               <Fingerprint className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
               {form.data.registration_source==='sha'&&<CheckCircle2 className="h-4 w-4 text-emerald-600" />}
             </div>
             <h3 className="mt-3 text-sm font-bold text-slate-900 dark:text-slate-100">SHA / HIE patient</h3>
             <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">Use an identifier and verify through the configured provider workflow.</p>
           </button>
         </div>
       </section>

       {/* SHA LOOKUP */}
       {form.data.registration_source==='sha' && (
         <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm space-y-4">
           <div className="grid gap-4 sm:grid-cols-2">
             <div className="space-y-1.5">
               <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Identifier type *</Label>
               <select value={form.data.identifier_type} onChange={e=>form.setData('identifier_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100 focus-visible:ring-emerald-500">
                 <option>National ID</option><option>ClientRegistry ID</option><option>Birth Notification</option><option>Birth Certificate</option><option>Refugee ID</option><option>Mandate Number</option>
               </select>
             </div>
             <Field label="Identifier number" name="identifier_number" form={form} required placeholder="Enter ID number"/>
           </div>
           
           <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
             <p className="max-w-xl text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">Client Registry lookup uses the documented fetch-client operation. Eligibility is a separate API operation; no demographics are inferred when lookup returns no record.</p>
             <Button type="button" variant="outline" onClick={lookupSha} disabled={lookupBusy||!can.shaLookup} className="h-9 rounded-xl border-slate-200 dark:border-slate-700 text-xs font-semibold">
               {lookupBusy?<><span className="mr-2 inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-r-transparent align-[-2px]"/>Fetching details…</>:'Fetch details by ID'}
             </Button>
           </div>
           
           {lookupStatus && <p className="rounded-xl bg-slate-50 dark:bg-slate-800/50 p-3 text-xs text-slate-600 dark:text-slate-300">{lookupStatus}</p>}
           
           {registryPatient && (
             <div className="rounded-xl border border-emerald-200 bg-emerald-50/30 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/10 space-y-4">
               <div className="flex flex-wrap items-start justify-between gap-3">
                 <div>
                   <p className="text-[10px] font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-400">Client Registry result</p>
                   <h3 className="mt-1 text-sm font-bold text-slate-900 dark:text-slate-100">{[registryPatient.first_name,registryPatient.middle_name,registryPatient.last_name].filter(Boolean).join(' ')||'Name not returned'}</h3>
                   <p className="text-[11px] text-slate-500 dark:text-slate-400">CR ID: {registryPatient.id} · DOB: {registryPatient.date_of_birth||'Not returned'} · {registryPatient.county||'County not returned'}</p>
                 </div>
                 <Button type="button" size="sm" variant="outline" onClick={()=>{setFormFromRegistry(registryPatient);setStep(3);}} className="h-8 rounded-lg text-xs">Register this patient</Button>
               </div>
               
               <div className="border-t border-emerald-200/50 dark:border-emerald-900/50 pt-3">
                 <div className="flex items-center justify-between gap-3 mb-2">
                   <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Dependants returned by the registry</h4>
                   <span className="text-[10px] font-medium text-slate-500">{registryDependants.length} found</span>
                 </div>
                 {registryDependants.length===0 ? (
                   <p className="text-xs text-slate-500 dark:text-slate-400">No dependant records were returned for this principal member.</p>
                 ) : (
                   <div className="divide-y divide-emerald-200/50 dark:divide-emerald-900/50">
                     {registryDependants.map((d:any,i:number)=>(
                       <div key={`${d.id||'dependent'}-${i}`} className="flex flex-wrap items-center justify-between gap-3 py-2.5">
                         <div>
                           <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">{[d.first_name,d.middle_name,d.last_name].filter(Boolean).join(' ')||'Name not returned'}</p>
                           <p className="text-[10px] text-slate-500 dark:text-slate-400">CR ID: {d.id||'Not returned'} · {d.relationship||'Relationship not returned'}</p>
                           <p className={`mt-0.5 text-[10px] font-medium ${d.relationship_verified?'text-emerald-600 dark:text-emerald-400':'text-amber-600 dark:text-amber-400'}`}>{d.relationship_verified?'Registry-listed dependant':'Unconfirmed dependant — manual review required'}</p>
                         </div>
                         <Button type="button" size="sm" variant="outline" disabled={!d.id} onClick={()=>chooseDependant(d)} className="h-7 text-[10px] rounded-md">Select dependant</Button>
                       </div>
                     ))}
                   </div>
                 )}
               </div>
             </div>
           )}
         </section>
       )}

       </>)}

       {step === 2 && (
         <section className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-[#111c2d] space-y-5">
           <div className="flex items-start gap-3"><div className="rounded-xl bg-emerald-50 p-3 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300"><ShieldCheck className="h-6 w-6"/></div><div><h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Verify the principal member</h2><p className="mt-1 text-sm text-slate-500 dark:text-slate-400">The dependant visit cannot be created until authorization is confirmed.</p></div></div>
           <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-300">{integrationMode === "development" ? "Development mode: OTP and biometric results are simulated. No SMS, live HIE request, biometric sample, or template is used." : "Live authorization is disabled until the approved DHA/HIE OTP or biometric request and response contract is configured. This environment will not simulate success."}</div>
           <div className="grid gap-3 sm:grid-cols-2">
             <button type="button" onClick={()=>{setAuthorizationMethod('otp');setAuthorizationChallenge(null);setAuthorizationCode(null);setAuthorizationStatus('');}} className={`rounded-xl border p-4 text-left ${authorizationMethod==='otp'?'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20':'border-slate-200 dark:border-slate-700'}`}><MessageSquare className="mb-2 h-5 w-5 text-emerald-600"/><span className="block text-sm font-semibold">Send OTP to principal</span><span className="mt-1 block text-xs text-slate-500">Use a one-time code for this authorization challenge.</span></button>
             <button type="button" onClick={()=>{setAuthorizationMethod('biometric');setAuthorizationChallenge(null);setAuthorizationCode(null);setAuthorizationStatus('');}} className={`rounded-xl border p-4 text-left ${authorizationMethod==='biometric'?'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20':'border-slate-200 dark:border-slate-700'}`}><Fingerprint className="mb-2 h-5 w-5 text-emerald-600"/><span className="block text-sm font-semibold">Principal biometric confirmation</span><span className="mt-1 block text-xs text-slate-500">Simulate a provider-confirmed biometric match.</span></button>
           </div>
           {!authorizationChallenge && <Button type="button" disabled={authorizationBusy} onClick={()=>startAuthorization(authorizationMethod)} className="bg-emerald-700 text-white hover:bg-emerald-800">{authorizationBusy?<><LoaderCircle className="mr-2 h-4 w-4 animate-spin"/>Starting…</>:(authorizationMethod==='otp'?'Send development OTP':'Start biometric confirmation')}</Button>}
           {authorizationChallenge && authorizationMethod==='otp' && <div className="space-y-3 rounded-xl bg-slate-50 p-4 dark:bg-slate-900"><p className="text-sm font-semibold">Enter principal authorization code</p>{authorizationCode && <p className="text-xs text-emerald-700 dark:text-emerald-300">Development test code: <strong>{authorizationCode}</strong> (displayed only in mock mode)</p>}<Input aria-label="Principal OTP" id="principal-otp" inputMode="numeric" maxLength={12} value={authorizationOtp} onChange={e=>setAuthorizationOtp(e.target.value)} placeholder="Enter one-time code" className="max-w-sm"/><Button type="button" disabled={authorizationBusy||!authorizationOtp.trim()} onClick={()=>verifyAuthorization('otp',authorizationOtp)} className="bg-emerald-700 text-white hover:bg-emerald-800">{authorizationBusy?<><LoaderCircle className="mr-2 h-4 w-4 animate-spin"/>Verifying…</>:'Verify OTP'}</Button></div>}
           {authorizationChallenge && authorizationMethod==='biometric' && <Button type="button" disabled={authorizationBusy} onClick={()=>verifyAuthorization('biometric')} className="bg-emerald-700 text-white hover:bg-emerald-800">{authorizationBusy?<><LoaderCircle className="mr-2 h-4 w-4 animate-spin"/>Confirming…</>:'Simulate principal biometric match'}</Button>}
           {authorizationStatus && <p role="status" className="rounded-xl bg-slate-50 p-3 text-sm text-slate-700 dark:bg-slate-900 dark:text-slate-300">{authorizationStatus}</p>}
           <div className="flex justify-between"><Button type="button" variant="outline" onClick={()=>setStep(1)}><ChevronLeft className="mr-1 h-4 w-4"/>Back</Button><span className="text-xs text-slate-500 self-center">{authorizationVerified?'Authorization confirmed':'Verification required before continuing'}</span></div>
         </section>
       )}

       {step === 3 && (<>
       {/* PATIENT DETAILS */}
       <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm space-y-5">
         <div>
           <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Patient details</h2>
           <p className="text-xs text-slate-500 dark:text-slate-400">Only enter details available at registration; optional fields can be completed later.</p>
         </div>
         <div className="grid gap-4 md:grid-cols-3">
           <Field label="First name" name="first_name" form={form}/>
           <Field label="Middle name" name="middle_name" form={form}/>
           <Field label="Last name" name="last_name" form={form}/>
         </div>
         <div className="grid gap-4 md:grid-cols-3">
           <Field label="Full name (if known)" name="full_name" form={form} placeholder="Optional if names above are entered"/>
           <Field label="Date of birth" name="date_of_birth" form={form} type="date"/>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Sex</Label>
             <select value={form.data.sex} onChange={e=>form.setData('sex',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="">Not recorded</option><option value="female">Female</option><option value="male">Male</option><option value="intersex">Intersex</option><option value="unknown">Unknown</option>
             </select>
           </div>
         </div>
         <div className="grid gap-4 md:grid-cols-3">
           <Field label="Phone" name="phone" form={form}/>
           <Field label="Email" name="email" form={form} type="email"/>
           <Field label="Preferred language" name="preferred_language" form={form}/>
         </div>
         <div className="grid gap-4 md:grid-cols-3">
           <Field label="County" name="county" form={form}/>
           <Field label="Sub-county" name="sub_county" form={form}/>
           <Field label="Ward" name="ward" form={form}/>
         </div>
         <Field label="Address" name="address" form={form}/>
       </section>

       {/* SHA PRINCIPAL */}
       <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm space-y-4">
         <div>
           <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">SHA principal member (if applicable)</h2>
           <p className="text-xs text-slate-500 dark:text-slate-400">For SHA dependants, search the principal member above and select a dependant returned by the Client Registry. The server rechecks the relationship before saving.</p>
         </div>
         <div className="grid gap-4 sm:grid-cols-2">
           <input type="hidden" name="principal_member_client_registry_id" value={form.data.principal_member_client_registry_id}/>
           <Field label="Existing local principal patient ID (optional)" name="principal_member_patient_id" form={form} placeholder="Internal record ID"/>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Relationship</Label>
             <select value={form.data.relationship_type} onChange={e=>form.setData('relationship_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="child">Child</option><option value="spouse">Spouse</option><option value="guardian">Guardian</option><option value="other_dependent">Other dependant</option>
             </select>
           </div>
         </div>
         <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
           <AlertCircle className="inline h-3.5 w-3.5 mr-1.5 text-amber-500" />
           Do not enter the principal member's identity as the patient's identity. A verified provider relationship must be confirmed by the relevant SHA workflow.
         </p>
       </section>

       {/* Local consent capture stays on the local workflow. SHA dependant authorization is handled in the authorization step; do not ask staff to re-enter consent here. */}
       {form.data.registration_source === 'sha' && <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-4 text-sm text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-200">
         <div className="flex items-start gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" /><div><p className="font-semibold">Principal authorization completed in the previous step</p><p className="mt-1 text-xs leading-relaxed">This dependant flow does not ask staff to change consent status again. Principal authorization is recorded separately from clinical consent and does not itself claim SHA eligibility or payment approval.</p></div></div>
       </div>}
       {form.data.registration_source === 'local' && <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm space-y-4">
         <div>
           <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Payer & consent</h2>
           <p className="text-xs text-slate-500 dark:text-slate-400">These are local registration selections, not a confirmation of SHA eligibility or payment.</p>
         </div>
         <div className="grid gap-4 md:grid-cols-3">
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Payment type</Label>
             <select value={form.data.payment_type} onChange={e=>form.setData('payment_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="">Select payment type</option><option value="sha">SHA</option><option value="cash">Cash / self pay</option><option value="private_insurance">Private insurance</option><option value="corporate">Corporate</option><option value="exempt">Exempt</option><option value="other">Other</option>
             </select>
           </div>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Coverage type</Label>
             <select value={form.data.coverage_type} onChange={e=>form.setData('coverage_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="">Select coverage</option><option value="sha">SHA</option><option value="private_insurance">Private insurance</option><option value="corporate">Corporate</option><option value="self_pay">Self pay</option><option value="other">Other</option>
             </select>
           </div>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Consent purpose</Label>
             <select value={form.data.consent_type} onChange={e=>form.setData('consent_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="care_and_treatment">Care and treatment</option><option value="data_sharing">Health information sharing</option><option value="sha_processing">SHA processing</option><option value="communications">Patient communications</option>
             </select>
           </div>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Consent status</Label>
             <select value={form.data.consent_status} onChange={e=>form.setData('consent_status',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="granted">Granted</option><option value="denied">Denied</option><option value="pending">Pending</option>
             </select>
           </div>
           <div className="space-y-1.5">
             <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Consent capture method</Label>
             <select value={form.data.consent_method} onChange={e=>form.setData('consent_method',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
               <option value="written">Written</option><option value="verbal">Verbal</option><option value="electronic">Electronic</option><option value="guardian">Guardian / representative</option>
             </select>
           </div>
         </div>
       </section>}

         {duplicateStatus && <div role="status" className={`rounded-xl border p-3 text-sm ${duplicateMatches.length?'border-amber-200 bg-amber-50 text-amber-900':'border-slate-200 bg-slate-50 text-slate-700'} dark:bg-slate-900 dark:text-slate-300`}>{duplicateStatus}</div>}
         {duplicateMatches.length > 0 && <div className="rounded-xl border border-amber-200 bg-white dark:border-amber-900/50 dark:bg-slate-900"><div className="border-b border-amber-100 p-3 text-sm font-semibold">Possible existing patients</div>{duplicateMatches.map((patient:any)=><div key={patient.id} className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-3 last:border-0 dark:border-slate-800"><div><p className="text-sm font-semibold">{patient.full_name||'Name not recorded'}</p><p className="text-xs text-slate-500">{patient.medical_record_number} · DOB {patient.date_of_birth||'unknown'} · {patient.encounters_count} visit(s)</p></div><Button type="button" variant="outline" onClick={()=>router.visit(`/patients/${patient.id}`)}>Open record</Button></div>)}</div>}
       </>)}

       {step === 4 && (<>
       {/* VISIT CREATION */}
       <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111c2d] p-5 shadow-sm space-y-4">
         <label className="flex items-start gap-3 rounded-xl bg-emerald-50 p-4 dark:bg-emerald-950/20 cursor-pointer border border-emerald-100 dark:border-emerald-900/50">
           <input type="checkbox" checked={form.data.create_visit} onChange={e=>form.setData('create_visit',e.target.checked)} className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"/>
           <span>
             <span className="block text-sm font-bold text-slate-900 dark:text-slate-100">Create a visit now</span>
             <span className="text-xs text-slate-600 dark:text-slate-400">Register the patient and open an encounter in one step.</span>
           </span>
         </label>
         {form.data.create_visit && (
           <div className="grid gap-4 md:grid-cols-3 pt-2">
             <div className="space-y-1.5">
               <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Visit type</Label>
               <select value={form.data.visit_type} onChange={e=>form.setData('visit_type',e.target.value)} className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100">
                 <option value="outpatient">Outpatient</option><option value="inpatient">Inpatient</option><option value="emergency">Emergency</option><option value="follow_up">Follow-up</option><option value="procedure">Procedure</option>
               </select>
             </div>
             <Field label="Department" name="department" form={form}/>
             <Field label="Reason for visit" name="chief_complaint" form={form}/>
           </div>
         )}
       </section>

       </>)}

       {/* ERRORS & SUBMIT */}
       {Object.values(form.errors)[0] && <p className="rounded-xl bg-rose-50 p-3 text-sm font-medium text-rose-700 dark:bg-rose-950/30 dark:text-rose-400">{Object.values(form.errors)[0]}</p>}
       
       {step !== 2 && <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
         <Button type="button" variant="outline" onClick={()=>step===1?router.visit('/patients'):setStep(step===4?3:step===3?(form.data.principal_member_client_registry_id&&!authorizationVerified?2:1):1)} className="h-10 rounded-xl text-sm px-5 border-slate-200 dark:border-slate-700"><ChevronLeft className="mr-1 h-4 w-4"/>Back</Button>
         {step < 4 ? <Button type="button" onClick={()=>{if(step===1){if(form.data.registration_source==='sha'&&!registryPatient){setLookupStatus('Fetch and select a registry patient first.');return;}setStep(form.data.principal_member_client_registry_id&&!authorizationVerified?2:3);}else if(step===3){void advanceToVisit();}}} className="h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm px-6 font-semibold">Continue <ChevronRight className="ml-1 h-4 w-4"/></Button> : <Button type="submit" disabled={form.processing||duplicateBusy||(form.data.registration_source==='sha'&&!!form.data.principal_member_client_registry_id&&!authorizationVerified)} className="h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm px-6 font-semibold shadow-md shadow-emerald-900/10">{duplicateBusy?'Checking for duplicates…':form.processing?'Saving…':form.data.create_visit?'Register patient & create visit':'Register patient'}</Button>}
       </div>}

      </form>

      {/* SIDEBAR (ASIDE) */}
      <aside className="space-y-4">
        <div className="rounded-2xl border border-emerald-100/50 bg-gradient-to-br from-emerald-800 to-teal-900 p-6 text-white shadow-sm dark:border-slate-800">
          <HeartPulse className="h-8 w-8 text-emerald-300" />
          <h2 className="mt-4 text-lg font-bold">One patient record. Every visit.</h2>
          <p className="mt-2 text-sm leading-relaxed text-emerald-100/90">Repeat visits create new encounters linked to the existing patient record. They do not create a second patient.</p>
        </div>
        
        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-[#111c2d]">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Before saving</h3>
          <ul className="mt-3 space-y-3 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            <li className="flex gap-2.5">
              <Search className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              <span>Search the registry using the patient identifier before creating another record.</span>
            </li>
            <li className="flex gap-2.5">
              <Fingerprint className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              <span>SHA eligibility, identity lookup, consent and claim steps are separate provider operations.</span>
            </li>
            <li className="flex gap-2.5">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              <span>Missing demographic details can remain blank until verified or collected.</span>
            </li>
          </ul>
        </div>
      </aside>
     </div>
    </div>
   </main>
  </>
 );
}