<!DOCTYPE html>
<?php
    $site = data_get($page, 'props.site', []);
    $siteName = data_get($site, 'name', config('app.name', 'Hospital'));
    $siteDescription = data_get($site, 'description', 'Hospital information and healthcare services.');
    $pageTitle = data_get($page, 'props.pageTitle', $siteName);
    $pageDescription = data_get($page, 'props.pageDescription', $siteDescription);
    $siteUrl = data_get($site, 'url', config('app.url'));
    $siteLogo = data_get($site, 'logo_url');
    $siteFavicon = data_get($site, 'favicon_url') ?: asset('favicon.svg');
    $brandVersion = data_get($site, 'updated_at');
    if ($brandVersion) {
        $siteFavicon .= (str_contains($siteFavicon, '?') ? '&' : '?').'v='.rawurlencode($brandVersion);
    }
?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="application-name" content="<?php echo e($siteName); ?>">
        <meta name="description" content="<?php echo e($pageDescription); ?>">
        <meta name="theme-color" content="#18794e">
        <meta name="color-scheme" content="light dark">
        <?php if($siteUrl): ?>
            <link rel="canonical" href="<?php echo e(rtrim($siteUrl, '/')); ?><?php echo e(request()->getPathInfo() === '/' ? '/' : request()->getPathInfo()); ?>">
        <?php endif; ?>
        <meta property="og:site_name" content="<?php echo e($siteName); ?>">
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo e($pageTitle); ?> | <?php echo e($siteName); ?>">
        <meta property="og:description" content="<?php echo e($pageDescription); ?>">
        <?php if($siteUrl): ?>
            <meta property="og:url" content="<?php echo e(rtrim($siteUrl, '/')); ?><?php echo e(request()->getPathInfo()); ?>">
        <?php endif; ?>
        <?php if($siteLogo): ?>
            <meta property="og:image" content="<?php echo e($siteLogo); ?>">
        <?php endif; ?>
        <?php
            $structuredData = array_filter([
                '@context' => 'https://schema.org',
                '@type' => 'MedicalClinic',
                'name' => $siteName,
                'url' => $siteUrl,
                'description' => $pageDescription,
                'telephone' => data_get($site, 'phone'),
                'email' => data_get($site, 'email'),
                'address' => data_get($site, 'address') ? [
                    '@type' => 'PostalAddress',
                    'streetAddress' => data_get($site, 'address'),
                ] : null,
                'image' => $siteLogo,
            ], fn ($value) => $value !== null && $value !== '');
        ?>
        <script type="application/ld+json"><?php echo json_encode($structuredData, 15, 512) ?></script>
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($pageTitle); ?> | <?php echo e($siteName); ?>">
        <meta name="twitter:description" content="<?php echo e($pageDescription); ?>">
        <link rel="icon" href="<?php echo e($siteFavicon); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(data_get($site, 'apple_touch_icon_url') ?: asset('apple-touch-icon.png')); ?>">
        <?php if($siteLogo): ?>
            <link rel="preload" as="image" href="<?php echo e($siteLogo); ?>">
        <?php endif; ?>

        <script>
            (function () {
                const appearance = <?php echo json_encode($appearance ?? 'system', 15, 512) ?>;
                if (appearance === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    document.documentElement.classList.add('dark');
                }
            })();
        </script>
        <style>
            html { background-color: oklch(0.99 0.012 155); }
            html.dark { background-color: oklch(0.17 0.025 160); }
        </style>
        <?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (isset($component)) { $__componentOriginal56673881198e3a2924721e242dee6899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56673881198e3a2924721e242dee6899 = $attributes; } ?>
<?php $component = Inertia\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inertia::head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Inertia\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <title><?php echo e($pageTitle); ?> | <?php echo e($siteName); ?></title>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56673881198e3a2924721e242dee6899)): ?>
<?php $attributes = $__attributesOriginal56673881198e3a2924721e242dee6899; ?>
<?php unset($__attributesOriginal56673881198e3a2924721e242dee6899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56673881198e3a2924721e242dee6899)): ?>
<?php $component = $__componentOriginal56673881198e3a2924721e242dee6899; ?>
<?php unset($__componentOriginal56673881198e3a2924721e242dee6899); ?>
<?php endif; ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (isset($component)) { $__componentOriginal1830bdc8f8b965a5838ec47487b5507c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1830bdc8f8b965a5838ec47487b5507c = $attributes; } ?>
<?php $component = Inertia\View\Components\App::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inertia::app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Inertia\View\Components\App::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1830bdc8f8b965a5838ec47487b5507c)): ?>
<?php $attributes = $__attributesOriginal1830bdc8f8b965a5838ec47487b5507c; ?>
<?php unset($__attributesOriginal1830bdc8f8b965a5838ec47487b5507c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1830bdc8f8b965a5838ec47487b5507c)): ?>
<?php $component = $__componentOriginal1830bdc8f8b965a5838ec47487b5507c; ?>
<?php unset($__componentOriginal1830bdc8f8b965a5838ec47487b5507c); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH D:\ivona-wayside-clinic\resources\views/app.blade.php ENDPATH**/ ?>